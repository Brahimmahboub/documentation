{
	'name': 'Autogear CRM',
	'author': 'Autogear',
	'website': 'https://example.com',
	'category': 'Sales/CRM',
	'summary': 'CRM extensions for a multi-branch car parts company',
	'description': 'Extends CRM to manage parts inquiries and create quotations with optional discounts for workshops/mechanics.',
	'license': 'LGPL-3',
	'version': '18.0.1.0.0',
	'depends': ['crm', 'sale', 'stock'],
	'data': [
		'security/ir.model.access.csv',
		'views/res_partner_view.xml',
		'views/crm_lead_view.xml',
	],
	'installable': True,
	'application': False,
}