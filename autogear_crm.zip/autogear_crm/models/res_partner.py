from odoo import models, fields


class ResPartner(models.Model):
	_inherit = 'res.partner'

	customer_type = fields.Selection(
		selection=[
			('retail', 'Retail'),
			('workshop', 'Workshop/Mechanic'),
			('online', 'Online Customer'),
		],
		string='Customer Type',
		help='Classify the customer to control pricing rules and reporting.'
	)