from odoo import api, fields, models


class AutogearLeadLine(models.Model):
	_name = 'autogear.lead.line'
	_description = 'Autogear CRM Lead Part Line'

	lead_id = fields.Many2one(
		'crm.lead',
		string='Lead',
		required=True,
		ondelete='cascade',
	)
	product_id = fields.Many2one(
		'product.product',
		string='Product',
		required=True,
		domain=[('sale_ok', '=', True)],
	)
	qty = fields.Float(string='Quantity', default=1.0)
	price_unit = fields.Float(string='Unit Price')
	available_qty = fields.Float(
		string='Available Qty',
		compute='_compute_available_qty',
		help='On-hand quantity for this product.',
	)

	@api.depends('product_id')
	def _compute_available_qty(self):
		for line in self:
			line.available_qty = line.product_id.qty_available if line.product_id else 0.0