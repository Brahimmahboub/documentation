from odoo import api, fields, models, _
from odoo.exceptions import UserError


class CrmLead(models.Model):
	_inherit = 'crm.lead'

	warehouse_id = fields.Many2one('stock.warehouse', string='Warehouse')
	vehicle_make = fields.Char(string='Vehicle Make')
	vehicle_model = fields.Char(string='Vehicle Model')
	vehicle_year = fields.Char(string='Vehicle Year')
	lead_line_ids = fields.One2many('autogear.lead.line', 'lead_id', string='Parts Lines')

	@api.depends('lead_line_ids.qty', 'lead_line_ids.price_unit')
	def _compute_expected_revenue(self):
		"""Compute expected revenue as the sum of lead parts (qty * price_unit).
		This intentionally overrides the default CRM computation.
		"""
		for lead in self:
			total_amount = 0.0
			for line in lead.lead_line_ids:
				qty = line.qty or 0.0
				price = line.price_unit or 0.0
				total_amount += qty * price
			lead.expected_revenue = total_amount

	def action_create_quotation(self):
		"""Create a Sales Quotation from the parts lines on the lead.
		- Requires a customer on the lead
		- Copies warehouse if set
		- Adds order lines from parts
		- Applies 10% discount if customer is 'Workshop/Mechanic'
		- Posts a message in the lead chatter with a link to the quotation
		"""
		SaleOrder = self.env['sale.order']
		SaleOrderLine = self.env['sale.order.line']

		self.ensure_one()
		lead = self

		if not lead.partner_id:
			raise UserError(_('Please set a Customer on the lead before creating a quotation.'))

		order_vals = {
			'partner_id': lead.partner_id.id,
			'opportunity_id': lead.id,
			'origin': lead.name or '',
		}
		if lead.warehouse_id:
			order_vals['warehouse_id'] = lead.warehouse_id.id

		order = SaleOrder.create(order_vals)

		discount_percent = 10.0 if lead.partner_id.customer_type == 'workshop' else 0.0
		for part_line in lead.lead_line_ids:
			if not part_line.product_id:
				continue
			line_vals = {
				'order_id': order.id,
				'product_id': part_line.product_id.id,
				'name': part_line.product_id.get_product_multiline_description_sale() if hasattr(part_line.product_id, 'get_product_multiline_description_sale') else part_line.product_id.display_name,
				'product_uom_qty': part_line.qty or 0.0,
				'product_uom': part_line.product_id.uom_id.id,
				'price_unit': part_line.price_unit or part_line.product_id.lst_price,
				'discount': discount_percent,
			}
			SaleOrderLine.create(line_vals)

		# Post back-link in chatter
		lead.message_post(
			body=_('Quotation %s created from this lead.') % (order.name,),
			subtype_xmlid='mail.mt_note',
		)

		# Try to open the created quotation
		try:
			action = self.env.ref('sale.action_quotations_with_onboarding').read()[0]
		except Exception:
			action = self.env.ref('sale.action_quotations').read()[0]

		action['views'] = [(self.env.ref('sale.view_order_form').id, 'form')]
		action['res_id'] = order.id
		return action