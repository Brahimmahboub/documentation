from . import res_partner
from . import lead_line
from . import crm_lead